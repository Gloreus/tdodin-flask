uwsgi  /var/www/td-odin.ru/cfg/uwsgi.yaml
