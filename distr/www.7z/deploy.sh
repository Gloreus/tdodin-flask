7z a backup/`date +%Y-%m-%d-%T`.7z td-odin.ru
rm -rf td-odin.ru
7z x td-odin.ru.7z
rm td-odin.ru.7z
chown -R odin td-odin.ru
chmod -R 775 td-odin.ru
/etc/init.d/apache2 restart